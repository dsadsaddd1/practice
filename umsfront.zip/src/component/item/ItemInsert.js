import React from 'react'
import { insertFetchFn } from '../etc/NetworkUtils';

function ItemInsert() {
    const username = localStorage.getItem("LOGINER");

    function onSubmitHandler(e){
        e.preventDefault();
        const formData = new FormData(e.target);
        const itemName = formData.get('itemName');
        const price = formData.get('price');
        const discount = formData.get('discount');
        const ea = formData.get('ea');
        const itemDescribe = formData.get('itemDescribe');

        const dto = {
            username,
            itemName,
            price,
            discount,
            ea,
            itemDescribe
        };
        insertFetchFn("item", dto);
    }
  return (
    <div>
        <h2>상품 등록</h2>
        <form action='#' onSubmit={onSubmitHandler}>
            등록자 : <input name='username' value={username} readOnly/><br/>
            상품이름 : <input name='itemName'/><br/>
            가격 : <input name='price'/><br/>
            할인률 : <input name='discount'/><br/>
            재고 : <input name='ea'/><br/>
            상품정보 : <input name='itemDescribe'/><br/>
            <button>등록</button>
        </form>
    </div>
  )
}

export default ItemInsert