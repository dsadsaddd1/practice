import React, { useEffect, useState } from 'react'
import { useParams } from 'react-router-dom'
import { fetchFn } from '../etc/NetworkUtils';

function ItemUpdate() {
  const id = useParams().id;
  const [item, setItem] = useState(null);
  useEffect(() => {
    fetchFn("GET", `http://localhost:9007/api/item/id/${id}`, null)
      .then(data => {
        setItem(data.result);
      })
  }, [id]);

  // function onInputHandler(e){
  //   let val = e.target.value;

  //   let newItem = {...item, [e.target.id]:val};
  //   setItem(newItem);
  // }

  function onSubmitHandler(e) {
    e.preventDefault();
    const formData = new FormData(e.target);
    const itemName = formData.get("itemName");
    const price = formData.get("price");
    const discount = formData.get("discount");
    const ea = formData.get("ea");
    const itemDescribe = formData.get("itemDescribe");
    const dto = {
      id,
      itemName,
      price,
      discount,
      ea,
      itemDescribe
    };
    fetchFn("PUT", "http://localhost:9009/api/item", dto)
      .then(data => {
        window.location.href = `/item/detail/${data.result.id}`;
      })
  }
  return (
    <div>
      <h2>상품 수정</h2>
      {
        item !== null &&
        <form action='#' onSubmit={onSubmitHandler}>
          등록자 : username<br/>
          상품이름 : <input name='itemName' placeholder={item.itemName} /><br/>
          가격 : <input name='price' placeholder={item.price} /><br/>
          할인률 : <input name='discount' placeholder={item.discount} /><br/>
          재고 : <input name='ea' placeholder={item.ea} /><br/>
          상품정보 : <input name='itemDescribe' placeholder={item.itemDescribe} /><br/>
          <button>수정</button>
        </form>
      }
    </div>
  )
}

export default ItemUpdate