import React from 'react'
import { Link } from 'react-router-dom';

function ItemComp(props) {
    const item = props.item;
  return (
    <div>
        <p>등록자 : {item.username}</p>
        <p>상품이름 : <Link to={`/item/detail/${item.id}`}> {item.itemName}</Link></p>
        <p>가격 : {item.price}</p>
        <p>할인률 : {item.discount}</p>
        <p>할인가격 : {item.price*(100 - item.discount)/100}</p>
    </div>
  )
}

export default ItemComp