import React, { useEffect, useState } from 'react'

import ItemComp from './ItemComp';
import { fetchFn } from '../etc/NetworkUtils';
import ItemListPaging from './ItemListPaging';

function ItemList() {
    const [pageList, setPageList] = useState([]);

    useEffect(() => {
        fetchFn("GET", `http://localhost:9007/api/item/list?pageNum=0`).then(
            (data) => {
                setPageList(data.result.content);
            }
        );
    }, []);

    return (
        <div>
            {
                pageList.length > 0 && pageList.map(item => <ItemComp key={item.id} item={item} />)
            }

            <ItemListPaging setFn={setPageList} />
        </div>
    )
}

export default ItemList
