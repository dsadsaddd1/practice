import React from 'react'

function ItemDelete() {
  return (
    <div>
        <h2>상품 삭제</h2>
    </div>
  )
}

export default ItemDelete