import React from 'react'

function MainEx() {
  return (
    <div>
        Main
    </div>
  )
}

export default MainEx