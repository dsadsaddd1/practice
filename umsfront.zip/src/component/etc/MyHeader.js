import Container from 'react-bootstrap/Container';
import Nav from 'react-bootstrap/Nav';
import Navbar from 'react-bootstrap/Navbar';
import NavDropdown from 'react-bootstrap/NavDropdown';

function MyHeader() {

    const token = localStorage.getItem("BTOKEN");
    const username =localStorage.getItem("LOGINER");

  return (
    <Navbar bg="light" expand="lg">
      <Container>
        <Navbar.Brand href="/">맛집 카페</Navbar.Brand>
        <Navbar.Toggle aria-controls="basic-navbar-nav" />
        <Navbar.Collapse id="basic-navbar-nav">
          <Nav className="me-auto">
            { 
            token === "null" ? <>
            <Nav.Link href="/member/insert">회원가입</Nav.Link>
            <Nav.Link href="/member/login">로그인</Nav.Link> </>:<>
            <Nav.Link href="/member/logout">로그아웃</Nav.Link>
            <Nav.Link href={`/member/detail/${username}`}>내 정보</Nav.Link>
            </>
            }
            
          
            <NavDropdown title="Dropdown" id="basic-nav-dropdown">
              <NavDropdown.Item href="#action/3.1">Action</NavDropdown.Item>
              <NavDropdown.Item href="#action/3.2">
                Another action
              </NavDropdown.Item>
              <NavDropdown.Item href="#action/3.3">Something</NavDropdown.Item>
              <NavDropdown.Divider />
              <NavDropdown.Item href="#action/3.4">
                Separated link
              </NavDropdown.Item>
            </NavDropdown>
          </Nav>
        </Navbar.Collapse>
      </Container>
    </Navbar>
  )
}

export default MyHeader