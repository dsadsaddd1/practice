import React from 'react'

function EmptyPage() {
  return (
    <div>잘못된 주소입니다.</div>
  )
}

export default EmptyPage