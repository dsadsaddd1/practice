import React from 'react'
import { Link, useParams } from 'react-router-dom';
import { DeleteFetchFn } from '../etc/NetworkUtils';

function ReplyComp(props) {

    const LOGINER = localStorage.getItem("LOGINER");
    const reply = props.reply;
    const bid = useParams().id;

    function onclickReplyDeleteFn(e){
        e.preventDefault();

        let dto = {
            id: reply.id,
            bid
          }

        let replyDelete = window.confirm("정말로 삭제하시겠습니까?");
        if(replyDelete){
            
            DeleteFetchFn("reply", dto);
        }
    }

  return (
    <div>

        <p>{reply.username}</p>
        <p>{reply.content}</p>
        <p>{reply.createDate}</p>
        <p>{reply.updateDate}</p>

          <Link to={`/reply/update/${reply.id}`}>수정하기</Link>
          <button onClick={onclickReplyDeleteFn}>삭제하기</button>


        {/* {
          LOGINER === reply.username && <>
          <Link to={`/reply/update/${reply.id}`}>수정하기</Link>
          <button onClick={onclickReplyDeleteFn}>삭제하기</button>
      
          </>
        } */}

    </div>
  )
}

export default ReplyComp