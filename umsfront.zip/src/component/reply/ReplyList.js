import React, { useEffect, useState } from 'react'
import ReplyComp from './ReplyComp';
import { useParams } from 'react-router-dom';
import { fetchFn } from '../etc/NetworkUtils';

function ReplyList() {

    const bid = useParams().id;
    const [replies, setReplies] = useState([]);

    useEffect(() => {
        fetchFn("GET", `http://localhost:9007/api/reply/all/${bid}`, null)
        .then((data) => {
            setReplies(data.result);     
        })
    }, [bid]);


  return (
    <div>ReplyList
        {
            replies !== null &&   
            replies.length > 0 &&
            replies.map(reply => {
               return <ReplyComp key={reply.id} reply={reply}/>
            })      
        }
    </div>
  )
}

export default ReplyList