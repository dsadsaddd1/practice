import React from 'react'
import { useParams } from 'react-router-dom';
import { InsertFetchFn } from '../etc/NetworkUtils';

function ReplyInsert() {

    const username = localStorage.getItem("LOGINER");
    const bid = useParams().id;

    function onSubmitHandler(e){
        e.preventDefault();

        const formData = new FormData(e.target);
        const dto = {
        content: formData.get("content"),
        username,
        bid
        }

        InsertFetchFn("reply", dto);

    }

  return (
    <div>
        <form action='#' onSubmit={onSubmitHandler}>
            내용 <input name='content'/>
            <button>작성</button>
        </form>


    </div>
  )
}

export default ReplyInsert