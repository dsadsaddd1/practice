import React, { useEffect, useState } from 'react'
import { useParams } from 'react-router-dom'
import { UpdateFetchFn, fetchFn } from '../etc/NetworkUtils';

function ReplyUpdate() {

  //  const LOGINER = localStorage.getItem("LOGINER");
    const id = useParams().id;
    const [reply, setReply] = useState(null);

    useEffect(() => {
        fetchFn("GET", `http://localhost:9007/api/reply/id/${id}`, null)
        .then((data) => {

            // if(LOGINER === username){
            //     setReply(data.result);
            // } else {
            //     window.location.href=`/`;
            // }

            setReply(data.result);
        });
    }, [id]);

    function onInputHandler(e){
        
        let val = e.target.value;
        let newReply = {...reply, [e.target.name]:val};
        setReply(newReply);
    }

    function onSubmitHandler(e){
        e.preventDefault();

        const formData = new FormData(e.target);
        const content = formData.get("content");

        const dto = {
            id,
            username: reply.username,
            content
        }

        UpdateFetchFn("reply", dto);
    }

  return (
    <div>
        <h2>댓글 수정 </h2>

        { reply !== null && <form action='#' onSubmit={onSubmitHandler}>
        
        <input name='content' value={reply.content} onInput={onInputHandler}/><br/>
            <button>수정</button>
        </form>
        }   
    </div>
  )
}

export default ReplyUpdate