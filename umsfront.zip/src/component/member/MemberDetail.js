import React, { useEffect, useState } from 'react'
import { Link, useParams } from 'react-router-dom';
import { fetchFn } from '../etc/NetworkUtils';

function MemberDetail() {
    const username = useParams().username;
    const [member, setMember] = useState(null);
    const LOGINER = localStorage.getItem("LOGINER");

    useEffect(()=>{
        fetchFn("GET", `http://localhost:9007/api/member/name/${username}`, null)
        .then(data=>{
            setMember(data.result);
        })
    },[username])

  return (
    <div>
        <h2>회원 정보 자세히 보기</h2>
        {member !== null && <>
        <div className='member'>
            <p>id: {member.id}</p>
            <p>username: {member.username}</p>
            <p>name: {member.name}</p>
            <p>가입일: {member.createDate}</p>
            <p>수정일: {member.updateDate}</p>
        </div>
        <div>
            <Link to={"/member/list"}>목록보기 | </Link>
            <Link to={"/member/insert"}>등록 | </Link>
            { LOGINER === member.username ? <>
            <Link to={`/member/updateName/${username}`}>수정 | </Link>
            <Link to={`/member/delete/${username}`}>삭제 | </Link>
            <Link to={`/member/logout`}>로그아웃 | </Link> </> :
            <Link to={`/member/login`}>로그인</Link>
            }
        </div>
        </>
        }
    </div>
  )
}

export default MemberDetail