import React, { useEffect, useState } from 'react'
import { fetchFn } from '../etc/NetworkUtils';
import MemberComp from './MemberComp';

function MemberList() {
   
    const [members, setMembers] = useState([]);

    useEffect(()=>{
        fetchFn("GET", "http://localhost:9007/api/member/all", null)
        .then(data => {
            console.log(data.result);
            setMembers(data.result);
        })
    },[])


  return (
    <div>
        <h2>회원 목록</h2>
        {
            members.length>0 && members.map(member => <MemberComp key={member.id} member={member}/>)
        }
    </div>
  )
}

export default MemberList