import React from 'react'
import { fetchFn } from '../etc/NetworkUtils';

function MemberLogin() {
    localStorage.setItem("BTOKEN", null);

    function onSubmitHandler(e){
        e.preventDefault();
        const formData = new FormData(e.target);
        const username = formData.get("username");
        const password = formData.get("password")
        const dto = {
            username, password
        }

        fetchFn("POST", "http://localhost:9007/api/auth/login", dto)
        .then(data=>{
            localStorage.setItem("BTOKEN", data.result.token);
            localStorage.setItem("LOGINER", data.result.username);
            localStorage.setItem("ROLE", data.result.role);
            window.location.href="/";
        });
    }

  return (
    <div>
        <h2>로그인</h2>
        <form action='#' onSubmit={onSubmitHandler}>
            username : <input name='username'/><br/>
            password : <input name='password'/><br/>
            <button>로그인</button>
        </form>
    </div>
  )
}

export default MemberLogin