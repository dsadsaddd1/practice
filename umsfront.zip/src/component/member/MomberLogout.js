import React from 'react'

function MemberLogout() {
    localStorage.setItem("BTOKEN", null);

    window.location.href="/member/login";
  return (
    <div>
        
    </div>
  )
}

export default MemberLogout