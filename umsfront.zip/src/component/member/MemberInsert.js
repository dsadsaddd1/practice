import React, { useState } from 'react'
import { fetchFn, idCheckFetFn } from '../etc/NetworkUtils';

function MemberInsert() {
    localStorage.setItem("BTOKEN", null);
    const [idCheckResult, setIdCheckResult] = useState('');

    function onSubmitHandler(e){
        e.preventDefault();
        const formData = new FormData(e.target);
        
        const dto = {
            username : formData.get("username"),
            name : formData.get("name"),
            password : formData.get("password"),
            password2 : formData.get("password2")
        }

        fetchFn("POST", "http://localhost:9007/api/auth/insert", dto)
        .then(data=>{
            console.log(data.result);
            window.location.href=`/member/login`;
        })
    }

    function onChangeHandler(e) {
        const username = e.target.value;
        if (username !== "") {
            idCheckFetFn(username)
                .then(data => {
                    setIdCheckResult(data.result)
                }) 
        }else{
            setIdCheckResult("");
        }
    }

  return (
    <div>
        <h2>회원 가입</h2>
        <form action='#' onSubmit={onSubmitHandler}>
        
            아이디 : <input name='username' onChange={onChangeHandler}/> {idCheckResult}<br/>
            이름 : <input name='name'/><br/>
            비밀번호 : <input name='password'/><br/>
            비밀번호2 : <input name='password2'/><br/>
            <button>회원가입</button>
        </form>
    </div>
  )
}

export default MemberInsert