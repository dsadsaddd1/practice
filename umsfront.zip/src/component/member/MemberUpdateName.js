import React, { useEffect, useState } from 'react'
import { Link, useParams } from 'react-router-dom'
import { fetchFn } from '../etc/NetworkUtils';

function MemberUpdateName() {
    const username = useParams().username;
    const [member, setMember] = useState(null);

    useEffect(()=>{
        fetchFn("GET", `http://localhost:9007/api/member/name/${username}`, null)
        .then(data=>{
            setMember(data.result);
        })
    },[username]);

    function onSubmitHandler(e){
        e.preventDefault();
        const formData = new FormData(e.target);
        const name = formData.get("name");
        const password = formData.get("password");

        const dto = {
            username, name, password
        }

        fetchFn("PUT", "http://localhost:9007/api/member/name", dto)
        .then(data=>{
            console.log(data.result)
            window.location.href=`/member/detail/${data.result.username}`;
        })
    }

    function onInputHandler(e){
        let val = e.target.value;
        let newMember = {...member, [e.target.name]:val};
        setMember(newMember);
    }

  return (
    <div>
        <h2>회원 정보 수정</h2>
        {
            member !== null &&
            <form action='#' onSubmit={onSubmitHandler}>
                username : <input value={username} disabled/><br/>
                이름 : <input name='name' value={member.name} onInput={onInputHandler}/><br/>
                password : <input name='password'/><br/>
                <button>이름 수정</button>
                <Link to={`/member/updatePassword/${username}`}>비밀번호 수정</Link>
            </form>
        }
    </div>
  )
}

export default MemberUpdateName