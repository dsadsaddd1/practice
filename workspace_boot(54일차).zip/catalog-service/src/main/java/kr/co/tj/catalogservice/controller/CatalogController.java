package kr.co.tj.catalogservice.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/catalog-service")
public class CatalogController {
	
	@GetMapping("/health_check") // 서버가 잘 돌아가는지 체크
	public String status() {
		return "catalog service입니다";
	}

}
