package kr.co.tj.orderservice.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/order-service")
public class OrderController {

	@GetMapping("/health_check") // 서버가 잘 돌아가는지 체크
	public String status() {
		return "order service입니다";
	}
	
}
