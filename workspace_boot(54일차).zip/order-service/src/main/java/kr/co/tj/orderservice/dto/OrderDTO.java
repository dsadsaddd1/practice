package kr.co.tj.orderservice.dto;

import java.io.Serializable;
import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class OrderDTO implements Serializable{
	
	private static final long serialVersionUID = 1L;
	
	private String username;
	
	private String productId;
	
	private String orderId;
	
	private Long qty;
	
	private Long unitPrice;
	
	private Long totalPrice;
	
	private Date createAt;
	private Date updateAt;

}
