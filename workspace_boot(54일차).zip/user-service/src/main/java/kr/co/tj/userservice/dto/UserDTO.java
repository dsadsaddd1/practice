package kr.co.tj.userservice.dto;

import java.io.Serializable;
import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class UserDTO implements Serializable{
	
	private static final long serialVersionUID = 1L;
	
	private String id;
	
	private String username;
	
	private String password;
	
	private String name;
	
	private Date createAt;
	
	private Date updateAt;
	
	public UserDTO toUserDTO(UserEntity userEntity) {
		
		this.id = userEntity.getId();
		
		return this;
	}
	
	public UserEntity toUserEntity() {
		return UserEntity.builder()
				.username(username)
				.password(password)
				.name(name)
				.createAt(createAt)
				.updateAt(updateAt)
				.build();
	}
	
	public UserResponse toUserResponse() { // 이미 만들어진 UserDTO의 객체(userDTO)를 사용하여 만들기 때문에 더 간단히 작성 가능
		return UserResponse.builder()
				.username(username)
				.name(name)
				.createAt(createAt)
				.updateAt(updateAt)
				.build();
	}

	public static UserDTO toUserDTO(UserRequest ureq) {
		return UserDTO.builder()
				.username(ureq.getUsername())
				.password(ureq.getPassword())
				.name(ureq.getName())
				.build();
	}

	

}
