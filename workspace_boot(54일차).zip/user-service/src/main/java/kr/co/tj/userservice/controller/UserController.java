package kr.co.tj.userservice.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import kr.co.tj.userservice.UserService;
import kr.co.tj.userservice.dto.UserDTO;
import kr.co.tj.userservice.dto.UserRequest;
import kr.co.tj.userservice.dto.UserResponse;

@RestController
@RequestMapping("/user-service")
public class UserController {
	
	@Autowired
	private Environment env;
	
	@Autowired
	private UserService userService;
	
	@PostMapping("/users")
	public ResponseEntity<?> createUser(@RequestBody UserRequest userRequest) {
		UserDTO userDTO = UserDTO.toUserDTO(userRequest);
		
		userDTO = userService.createUser(userDTO);
		UserResponse userResponse = userDTO.toUserResponse();
		
		return ResponseEntity.status(HttpStatus.CREATED).body(userResponse);
	}
	
	@GetMapping("/health_check") // 서버가 잘 돌아가는지 체크
	public String status() {
		return "user service입니다"+env.getProperty("local.server.port");
	}
	
	

}
