package kr.co.tj.userservice;

import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import kr.co.tj.userservice.dto.UserDTO;
import kr.co.tj.userservice.dto.UserEntity;
import kr.co.tj.userservice.jpa.UserRepository;

@Service
public class UserService {
	
	@Autowired
	private UserRepository userRepository;

	public UserDTO createUser(UserDTO userDTO) {
		userDTO = getDate(userDTO);
		
		UserEntity userEntity = userDTO.toUserEntity();
		
		userEntity = userRepository.save(userEntity);
		
		return userDTO.toUserDTO(userEntity);
	}

	private UserDTO getDate(UserDTO userDTO) {
		Date date = new Date();
		
		if(userDTO.getCreateAt() == null) {
			userDTO.setCreateAt(date);
		}
		
		userDTO.setUpdateAt(date);
		return userDTO;
	}
	
}
